<!--Skip This Ad Button-->
<!--<!DOCTYPE html>-->
<!--<html>-->
<!--<head>-->
<!--<meta name="viewport" content="width=device-width, initial-scale=1">-->
<!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">-->
<style>
.btn {
  background-color: #417d7c;
  border: none;
  color: white;
  padding: 12px 30px;
  cursor: pointer;
  font-size: 20px;
  pointer-events:none;
text-decoration: none;
}


</style>
</head>
<body>

<a style ='text-decoration: none; pointer-events:none' href="itms-services://?action=download-manifest&url=https://file.ipa-apps.me/plist/ChimeraJB_lol.plist">
			<button class="btn" style="width:100%">Please wait <span id="displaySeconds"></span> </button>
		</a></body>
</html>


<script src="//acdcdn.com/script/suv4.js" data-adel="lwsu" cdnd="acdcdn.com" zid="5031655"></script>

<script data-cfasync="false" type="text/javascript" src="https://www.onclickalgo.com/a/display.php?r=5031675"></script>

<script>

		var count = 5; // Number of remaining seconds.
		var counter; // Handle for the countdown event.

		function start() {
			counter = setInterval(timer, 1000);
		}

		function timer() {
			// Show the number of remaining seconds on the web page.
			var output = document.getElementById("displaySeconds");
			output.innerHTML = count + ' seconds';

			// Decrease the remaining number of seconds by one.
			count--;

			// Check if the counter has reached zero.
			if (count < 0) { // If the counter has reached zero...
				// Stop the counter.
				clearInterval(counter);
				document.querySelectorAll('.btn')[0].innerText = 'SKIP THIS AD';
				document.querySelectorAll('.btn')[0].style.backgroundColor = '#4f7d59';
				document.querySelectorAll('.btn')[0].style.color = '#000000';
				document.querySelectorAll('.btn')[0].style.pointerEvents = 'auto';
				// Start the download.

				return;
			}
		}

			// Start the countdown timer when the page loads.
			window.addEventListener("load", start, false);
</script>
<!--Skip This Ad Button-->



<br><br>




<!--Dark Mode For iOS-->
<style>
:root {
  color-scheme: light dark;
  --body-background-color: white;
  --body-text-color: #2F2F2F;
}
@media (prefers-color-scheme: dark) {
  :root {
    --body-background-color: #222222;
    --body-text-color: #E2E2E2;
  }
}
body {
  background-color: var(--body-background-color);
  color: var(--body-text-color);
}



body {
  background-color: var(--body-background-color);
  color: var(--body-text-color);
}
.alert {
  padding: 5px;
  background-color: #218185;
  color: #cacccc;
  
  
} 

</style>
</head>
<body>
<!--Dark Mode For iOS-->
    
   
   
<!--Phone screen support-->
<meta name="viewport" content="with=device=width, initial-scale=1"






<!--ads iframe-->
<center>
<a href="https://itnuzleafan.com/4/3553033" target="_blank"><img src="https://ipa-apps.me/Download.GIF" alt="Download Free Game" /></a>


<!--ads iframe-->






<!--Block Ad Block-->
<script type="text/javascript"  charset="utf-8">
// Place this code snippet near the footer of your page before the close of the /body tag
// LEGAL NOTICE: The content of this website and all associated program code are protected under the Digital Millennium Copyright Act. Intentionally circumventing this code may constitute a violation of the DMCA.
                            
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}(';q P=\'\',28=\'21\';1P(q i=0;i<12;i++)P+=28.11(C.K(C.O()*28.G));q 2w=4,2H=6e,2G=6c,2S=6a,2f=D(t){q o=!1,i=D(){z(k.1h){k.34(\'2Y\',e);F.34(\'1T\',e)}S{k.33(\'2W\',e);F.33(\'26\',e)}},e=D(){z(!o&&(k.1h||67.2y===\'1T\'||k.32===\'2Z\')){o=!0;i();t()}};z(k.32===\'2Z\'){t()}S z(k.1h){k.1h(\'2Y\',e);F.1h(\'1T\',e)}S{k.2U(\'2W\',e);F.2U(\'26\',e);q n=!1;2X{n=F.5Z==6g&&k.1X}2s(r){};z(n&&n.3a){(D a(){z(o)H;2X{n.3a(\'14\')}2s(e){H 5E(a,50)};o=!0;i();t()})()}}};F[\'\'+P+\'\']=(D(){q t={t$:\'21+/=\',5B:D(e){q a=\'\',d,n,o,c,s,l,i,r=0;e=t.e$(e);1f(r<e.G){d=e.17(r++);n=e.17(r++);o=e.17(r++);c=d>>2;s=(d&3)<<4|n>>4;l=(n&15)<<2|o>>6;i=o&63;z(2q(n)){l=i=64}S z(2q(o)){i=64};a=a+X.t$.11(c)+X.t$.11(s)+X.t$.11(l)+X.t$.11(i)};H a},13:D(e){q n=\'\',d,l,c,s,r,i,a,o=0;e=e.1r(/[^A-5A-5z-9\\+\\/\\=]/g,\'\');1f(o<e.G){s=X.t$.1M(e.11(o++));r=X.t$.1M(e.11(o++));i=X.t$.1M(e.11(o++));a=X.t$.1M(e.11(o++));d=s<<2|r>>4;l=(r&15)<<4|i>>2;c=(i&3)<<6|a;n=n+T.U(d);z(i!=64){n=n+T.U(l)};z(a!=64){n=n+T.U(c)}};n=t.n$(n);H n},e$:D(t){t=t.1r(/;/g,\';\');q n=\'\';1P(q o=0;o<t.G;o++){q e=t.17(o);z(e<1A){n+=T.U(e)}S z(e>5q&&e<5K){n+=T.U(e>>6|6M);n+=T.U(e&63|1A)}S{n+=T.U(e>>12|2K);n+=T.U(e>>6&63|1A);n+=T.U(e&63|1A)}};H n},n$:D(t){q o=\'\',e=0,n=6J=1n=0;1f(e<t.G){n=t.17(e);z(n<1A){o+=T.U(n);e++}S z(n>71&&n<2K){1n=t.17(e+1);o+=T.U((n&31)<<6|1n&63);e+=2}S{1n=t.17(e+1);2A=t.17(e+2);o+=T.U((n&15)<<12|(1n&63)<<6|2A&63);e+=3}};H o}};q a=[\'6V==\',\'3F\',\'3G=\',\'3H\',\'3K\',\'42=\',\'45=\',\'3u=\',\'3f\',\'3g\',\'4V=\',\'4U=\',\'5i\',\'75\',\'7H=\',\'3I\',\'3J=\',\'3L=\',\'3N=\',\'3P=\',\'3E=\',\'3V=\',\'3Z==\',\'41==\',\'43==\',\'3D==\',\'3s=\',\'4S\',\'4R\',\'4T\',\'4p\',\'4n\',\'4b\',\'4h==\',\'4j=\',\'4r=\',\'4H=\',\'4G==\',\'4t=\',\'4z\',\'4x=\',\'4w=\',\'3B==\',\'4Z=\',\'4u==\',\'4v==\',\'4y=\',\'4A=\',\'4C\',\'4D==\',\'4E==\',\'4F\',\'4B==\',\'4q=\'],p=C.K(C.O()*a.G),w=t.13(a[p]),Y=w,L=1,W=\'#4c\',r=\'#4d\',g=\'#4e\',b=\'#4f\',M=\'\',f=\'4g!\',v=\'4i 4k 4l 4m\\\'4o 4I 4s 2i 2h. 4J\\\'s 53.  55 56\\\'t?\',u=\'57 58 59-5a, 54 5b\\\'t 5d 5e X 5f 5k.\',s=\'I 5h, I 5j 5c 52 2i 2h.  51 4M 4N!\',o=0,y=0,n=\'4O.4P\',l=0,A=e()+\'.2I\';D m(t){z(t)t=t.1L(t.G-15);q o=k.2J(\'4Q\');1P(q n=o.G;n--;){q e=T(o[n].1I);z(e)e=e.1L(e.G-15);z(e===t)H!0};H!1};D h(t){z(t)t=t.1L(t.G-15);q e=k.4L;x=0;1f(x<e.G){1m=e[x].1p;z(1m)1m=1m.1L(1m.G-15);z(1m===t)H!0;x++};H!1};D e(t){q n=\'\',o=\'21\';t=t||30;1P(q e=0;e<t;e++)n+=o.11(C.K(C.O()*o.G));H n};D i(o){q i=[\'4X\',\'4Y==\',\'49\',\'4K\',\'2v\',\'4a==\',\'44=\',\'48==\',\'3d=\',\'3e==\',\'3j==\',\'3k==\',\'3l\',\'3n\',\'3q\',\'2v\'],r=[\'2n=\',\'3A==\',\'3z==\',\'3y==\',\'3x=\',\'3w\',\'3v=\',\'3t=\',\'2n=\',\'3r\',\'3p==\',\'3o\',\'3c==\',\'3m==\',\'3i==\',\'3h=\'];x=0;1R=[];1f(x<o){c=i[C.K(C.O()*i.G)];d=r[C.K(C.O()*r.G)];c=t.13(c);d=t.13(d);q a=C.K(C.O()*2)+1;z(a==1){n=\'//\'+c+\'/\'+d}S{n=\'//\'+c+\'/\'+e(C.K(C.O()*20)+4)+\'.2I\'};1R[x]=23 24();1R[x].1U=D(){q t=1;1f(t<7){t++}};1R[x].1I=n;x++}};D Q(t){};H{2m:D(t,r){z(3T k.N==\'47\'){H};q o=\'0.1\',r=Y,e=k.1b(\'1x\');e.16=r;e.j.1l=\'1J\';e.j.14=\'-1i\';e.j.10=\'-1i\';e.j.1c=\'2c\';e.j.V=\'46\';q d=k.N.2N,a=C.K(d.G/2);z(a>15){q n=k.1b(\'2a\');n.j.1l=\'1J\';n.j.1c=\'1v\';n.j.V=\'1v\';n.j.10=\'-1i\';n.j.14=\'-1i\';k.N.3C(n,k.N.2N[a]);n.1d(e);q i=k.1b(\'1x\');i.16=\'2L\';i.j.1l=\'1J\';i.j.14=\'-1i\';i.j.10=\'-1i\';k.N.1d(i)}S{e.16=\'2L\';k.N.1d(e)};l=3Y(D(){z(e){t((e.1W==0),o);t((e.1Y==0),o);t((e.1S==\'2g\'),o);t((e.1G==\'2B\'),o);t((e.1K==0),o)}S{t(!0,o)}},27)},1O:D(e,c){z((e)&&(o==0)){o=1;F[\'\'+P+\'\'].1C();F[\'\'+P+\'\'].1O=D(){H}}S{q u=t.13(\'3X\'),y=k.3W(u);z((y)&&(o==0)){z((2H%3)==0){q l=\'3U=\';l=t.13(l);z(m(l)){z(y.1Q.1r(/\\s/g,\'\').G==0){o=1;F[\'\'+P+\'\'].1C()}}}};q p=!1;z(o==0){z((2G%3)==0){z(!F[\'\'+P+\'\'].2z){q d=[\'3S==\',\'3R==\',\'3Q=\',\'3O=\',\'3M=\'],h=d.G,r=d[C.K(C.O()*h)],a=r;1f(r==a){a=d[C.K(C.O()*h)]};r=t.13(r);a=t.13(a);i(C.K(C.O()*2)+1);q n=23 24(),s=23 24();n.1U=D(){i(C.K(C.O()*2)+1);s.1I=a;i(C.K(C.O()*2)+1)};s.1U=D(){o=1;i(C.K(C.O()*3)+1);F[\'\'+P+\'\'].1C()};n.1I=r;z((2S%3)==0){n.26=D(){z((n.V<8)&&(n.V>0)){F[\'\'+P+\'\'].1C()}}};i(C.K(C.O()*3)+1);F[\'\'+P+\'\'].2z=!0};F[\'\'+P+\'\'].1O=D(){H}}}}},1C:D(){z(y==1){q Z=2C.6W(\'2D\');z(Z>0){H!0}S{2C.6X(\'2D\',(C.O()+1)*27)}};q m=\'6Z==\';m=t.13(m);z(!h(m)){q c=k.1b(\'70\');c.1Z(\'72\',\'73\');c.1Z(\'2y\',\'1g/74\');c.1Z(\'1p\',m);k.2J(\'76\')[0].1d(c)};77(l);k.N.1Q=\'\';k.N.j.19+=\'R:1v !1a\';k.N.j.19+=\'1u:1v !1a\';q A=k.1X.1Y||F.35||k.N.1Y,p=F.6R||k.N.1W||k.1X.1W,a=k.1b(\'1x\'),L=e();a.16=L;a.j.1l=\'2r\';a.j.14=\'0\';a.j.10=\'0\';a.j.V=A+\'1z\';a.j.1c=p+\'1z\';a.j.2u=W;a.j.1V=\'6Q\';k.N.1d(a);q d=\'<a 1p="6C://6D.6E"><2j 16="2k" V="2P" 1c="40"><2x 16="2d" V="2P" 1c="40" 6F:1p="6G:2x/6H;6B,6I+6K+6L+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+6N+6O+6P/78/79/7a/7j/7u+/7v/7w+7x/7y+7z/7t/7A/7C/7D/7E/7F+7G/7B+7s+7r+7q+7c+7d/7e+7f/7g+7h/7b+7i+7k+7l+7m/7n+7o/7p/6S/6z+5W+6y/5G+5H+5I+5J+E+5L/5F/5M/5O/5P/5Q/+5R/5S++5T/5N/5D+5v/5C+5o+5p==">;</2j></a>\';d=d.1r(\'2k\',e());d=d.1r(\'2d\',e());q i=k.1b(\'1x\');i.1Q=d;i.j.1l=\'1J\';i.j.1y=\'1N\';i.j.14=\'1N\';i.j.V=\'5s\';i.j.1c=\'5t\';i.j.1V=\'2Q\';i.j.1K=\'.6\';i.j.2R=\'2t\';i.1h(\'5n\',D(){n=n.5u(\'\').5w().5x(\'\');F.2E.1p=\'//\'+n});k.1F(L).1d(i);q o=k.1b(\'1x\'),Q=e();o.16=Q;o.j.1l=\'2r\';o.j.10=p/7+\'1z\';o.j.5U=A-5V+\'1z\';o.j.6i=p/3.5+\'1z\';o.j.2u=\'#6k\';o.j.1V=\'2Q\';o.j.19+=\'J-1w: "6l 6m", 1o, 1t, 1s-1q !1a\';o.j.19+=\'6n-1c: 6p !1a\';o.j.19+=\'J-1k: 6j !1a\';o.j.19+=\'1g-1D: 1B !1a\';o.j.19+=\'1u: 6q !1a\';o.j.1S+=\'39\';o.j.2V=\'1N\';o.j.6s=\'1N\';o.j.6t=\'2l\';k.N.1d(o);o.j.6v=\'1v 6x 6r -6h 69(0,0,0,0.3)\';o.j.1G=\'2e\';q Y=30,w=22,M=18,x=18;z((F.35<38)||(5Y.V<38)){o.j.2T=\'50%\';o.j.19+=\'J-1k: 61 !1a\';o.j.2V=\'62;\';i.j.2T=\'65%\';q Y=22,w=18,M=12,x=12};o.1Q=\'<36 j="1j:#5X;J-1k:\'+Y+\'1E;1j:\'+r+\';J-1w:1o, 1t, 1s-1q;J-1H:68;R-10:1e;R-1y:1e;1g-1D:1B;">\'+f+\'</36><37 j="J-1k:\'+w+\'1E;J-1H:6b;J-1w:1o, 1t, 1s-1q;1j:\'+r+\';R-10:1e;R-1y:1e;1g-1D:1B;">\'+v+\'</37><6d j=" 1S: 39;R-10: 0.3b;R-1y: 0.3b;R-14: 29;R-2O: 29; 2o:6f 5g #5l; V: 25%;1g-1D:1B;"><p j="J-1w:1o, 1t, 1s-1q;J-1H:2p;J-1k:\'+M+\'1E;1j:\'+r+\';1g-1D:1B;">\'+u+\'</p><p j="R-10:6w;"><2a 6u="X.j.1K=.9;" 6o="X.j.1K=1;"  16="\'+e()+\'" j="2R:2t;J-1k:\'+x+\'1E;J-1w:1o, 1t, 1s-1q; J-1H:2p;2o-5y:2l;1u:1e;5r-1j:\'+g+\';1j:\'+b+\';1u-14:2c;1u-2O:2c;V:60%;R:29;R-10:1e;R-1y:1e;" 6T="F.2E.6Y();">\'+s+\'</2a></p>\'}}})();F.2M=D(t,e){q n=6U.6A,o=F.5m,a=n(),i,r=D(){n()-a<e?i||o(r):t()};o(r);H{4W:D(){i=1}}};q 2F;z(k.N){k.N.j.1G=\'2e\'};2f(D(){z(k.1F(\'2b\')){k.1F(\'2b\').j.1G=\'2g\';k.1F(\'2b\').j.1S=\'2B\'};2F=F.2M(D(){F[\'\'+P+\'\'].2m(F[\'\'+P+\'\'].1O,F[\'\'+P+\'\'].66)},2w*27)});',62,478,'|||||||||||||||||||style|document||||||var|||||||||if||vr6|Math|function||window|length|return||font|floor|||body|random|SuhhLyMVyYis||margin|else|String|fromCharCode|width||this|||top|charAt||decode|left||id|charCodeAt||cssText|important|createElement|height|appendChild|10px|while|text|addEventListener|5000px|color|size|position|thisurl|c2|Helvetica|href|serif|replace|sans|geneva|padding|0px|family|DIV|bottom|px|128|center|WDadKMBwIZ|align|pt|getElementById|visibility|weight|src|absolute|opacity|substr|indexOf|30px|ohRrSqjgQU|for|innerHTML|spimg|display|load|onerror|zIndex|clientHeight|documentElement|clientWidth|setAttribute||ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789||new|Image||onload|1000|oAyPyxgQWw|auto|div|babasbmsgx|60px|FILLVECTID2|visible|zVLqnDHxKx|hidden|blocker|ad|svg|FILLVECTID1|15px|TloFCBijZT|ZmF2aWNvbi5pY28|border|300|isNaN|fixed|catch|pointer|backgroundColor|cGFydG5lcmFkcy55c20ueWFob28uY29t|MMxNQizrFh|image|type|ranAlready|c3|none|sessionStorage|babn|location|RJFVAALqMs|KaRpWsPHIB|GrpQhzQfji|jpg|getElementsByTagName|224|banner_ad|swjQjZYJrE|childNodes|right|160|10000|cursor|ZCNoiqQrzP|zoom|attachEvent|marginLeft|onreadystatechange|try|DOMContentLoaded|complete|||readyState|detachEvent|removeEventListener|innerWidth|h3|h1|640|block|doScroll|5em|YmFubmVyX2FkLmdpZg|Y2FzLmNsaWNrYWJpbGl0eS5jb20|cHJvbW90ZS5wYWlyLmNvbQ|YWQtZm9vdGVy|YWQtY29udGFpbmVy|YWR2ZXJ0aXNlbWVudC0zNDMyMy5qcGc|d2lkZV9za3lzY3JhcGVyLmpwZw|YWRzLnlhaG9vLmNvbQ|YWRzLnp5bmdhLmNvbQ|YWRzYXR0LmFiY25ld3Muc3RhcndhdmUuY29t|bGFyZ2VfYmFubmVyLmdpZg|YWRzYXR0LmVzcG4uc3RhcndhdmUuY29t|ZmF2aWNvbjEuaWNv|c3F1YXJlLWFkLnBuZw|YXMuaW5ib3guY29t|YWQtbGFyZ2UucG5n|RGl2QWQ|Q0ROLTMzNC0xMDktMTM3eC1hZC1iYW5uZXI|YWQtbGI|YWRjbGllbnQtMDAyMTQ3LWhvc3QxLWJhbm5lci1hZC5qcGc|MTM2N19hZC1jbGllbnRJRDI0NjQuanBn|c2t5c2NyYXBlci5qcGc|NzIweDkwLmpwZw|NDY4eDYwLmpwZw|YmFubmVyLmpwZw|YWRBZA|insertBefore|QWRzX2dvb2dsZV8wNA|QWRMYXllcjE|YWRCYW5uZXJXcmFw|YWQtZnJhbWU|YWQtaGVhZGVy|QWRBcmVh|QWRGcmFtZTE|YWQtaW1n|QWRGcmFtZTI|Ly93d3cuZG91YmxlY2xpY2tieWdvb2dsZS5jb20vZmF2aWNvbi5pY28|QWRGcmFtZTM|Ly9hZHMudHdpdHRlci5jb20vZmF2aWNvbi5pY28|QWRGcmFtZTQ|Ly9hZHZlcnRpc2luZy55YWhvby5jb20vZmF2aWNvbi5pY28|Ly93d3cuZ3N0YXRpYy5jb20vYWR4L2RvdWJsZWNsaWNrLmljbw|Ly93d3cuZ29vZ2xlLmNvbS9hZHNlbnNlL3N0YXJ0L2ltYWdlcy9mYXZpY29uLmljbw|typeof|Ly9wYWdlYWQyLmdvb2dsZXN5bmRpY2F0aW9uLmNvbS9wYWdlYWQvanMvYWRzYnlnb29nbGUuanM|QWRMYXllcjI|querySelector|aW5zLmFkc2J5Z29vZ2xl|setInterval|QWRzX2dvb2dsZV8wMQ||QWRzX2dvb2dsZV8wMg|YWQtaW5uZXI|QWRzX2dvb2dsZV8wMw|YWdvZGEubmV0L2Jhbm5lcnM|YWQtbGFiZWw|468px|undefined|YWR2ZXJ0aXNpbmcuYW9sLmNvbQ|anVpY3lhZHMuY29t|YS5saXZlc3BvcnRtZWRpYS5ldQ|RGl2QWRD|EEEEEE|777777|0f66a1|FFFFFF|Welcome|QWRJbWFnZQ|It|QWREaXY|looks|like|you|RGl2QWRC|re|RGl2QWRB|c3BvbnNvcmVkX2xpbms|QWRCb3gxNjA|an|YWRUZWFzZXI|IGFkX2JveA|YWRfY2hhbm5lbA|YWRiYW5uZXI|YWRCYW5uZXI|YWRzZXJ2ZXI|YmFubmVyX2Fk|YmFubmVyaWQ|b3V0YnJhaW4tcGFpZA|YWRzbG90|cG9wdXBhZA|YWRzZW5zZQ|Z29vZ2xlX2Fk|Z2xpbmtzd3JhcHBlcg|QWRDb250YWluZXI|using|That|YWQuZm94bmV0d29ya3MuY29t|styleSheets|me|in|moc|kcolbdakcolb|script|RGl2QWQy|RGl2QWQx|RGl2QWQz|YWQtY29udGFpbmVyLTI|YWQtY29udGFpbmVyLTE|clear|YWRuLmViYXkuY29t|YWQubWFpbC5ydQ|YmFubmVyYWQ||Let|my|okay|we|Who|doesn|But|without|advertising|income|can|disabled|keep|making|site|solid|understand|QWQzMDB4MTQ1|have|awesome|CCC|requestAnimationFrame|click|3eUeuATRaNMs0zfml|gkJocgFtzfMzwAAAABJRU5ErkJggg|127|background|160px|40px|split|dEflqX6gzC4hd1jSgz0ujmPkygDjvNYDsU0ZggjKBqLPrQLfDUQIzxMBtSOucRwLzrdQ2DFO0NDdnsYq0yoJyEB0FHTBHefyxcyUy8jflH7sHszSfgath4hYwcD3M29I5DMzdBNO2IFcC5y6HSduof4G5dQNMWd4cDcjNNeNGmb02|reverse|join|radius|z0|Za|encode|Uv0LfPzlsBELZ|uJylU|setTimeout|SRWhNsmOazvKzQYcE0hV5nDkuQQKfUgm4HmqA2yuPxfMU1m4zLRTMAqLhN6BHCeEXMDo2NsY8MdCeBB6JydMlps3uGxZefy7EO1vyPvhOxL7TPWjVUVvZkNJ|E5HlQS6SHvVSU0V|j9xJVBEEbWEXFVZQNX9|1HX6ghkAR9E5crTgM|0t6qjIlZbzSpemi|2048|MjA3XJUKy|CGf7SAP2V6AjTOUa8IzD3ckqe2ENGulWGfx9VKIBB72JM1lAuLKB3taONCBn3PY0II5cFrLr7cCp|Kq8b7m0RpwasnR|UIWrdVPEp7zHy7oWXiUgmR3kdujbZI73kghTaoaEKMOh8up2M8BVceotd|BNyENiFGe5CxgZyIT6KVyGO2s5J5ce|14XO7cR5WV1QBedt3c|QhZLYLN54|e8xr8n5lpXyn|u3T9AbDjXwIMXfxmsarwK9wUBB5Kj8y2dCw|minWidth|120|F2Q|999|screen|frameElement||18pt|45px||||rbeRUPPmHD|event|200|rgba|133|500|106|hr|262|1px|null|8px|minHeight|16pt|fff|Arial|Black|line|onmouseout|normal|12px|24px|marginRight|borderRadius|onmouseover|boxShadow|35px|14px|bTplhb|x0z6tauQYvPxwT0VM1lH9Adt5Lp|now|base64|http|blockadblock|com|xlink|data|png|iVBORw0KGgoAAAANSUhEUgAAAKAAAAAoCAMAAABO8gGqAAAB|c1|1BMVEXr6|sAAADr6|192|sAAADMAAAsKysKCgokJCRycnIEBATq6uoUFBTMzMzr6urjqqoSEhIGBgaxsbHcd3dYWFg0NDTmw8PZY2M5OTkfHx|enp7TNTUoJyfm5ualpaV5eXkODg7k5OTaamoqKSnc3NzZ2dmHh4dra2tHR0fVQUFAQEDPExPNBQXo6Ohvb28ICAjp19fS0tLnzc29vb25ubm1tbWWlpaNjY3dfX1oaGhUVFRMTEwaGhoXFxfq5ubh4eHe3t7Hx8fgk5PfjY3eg4OBgYF|fn5EREQ9PT3SKSnV1dXks7OsrKypqambmpqRkZFdXV1RUVHRISHQHR309PTq4eHp3NzPz8|9999|innerHeight|pyQLiBu8WDYgxEZMbeEqIiSM8r|onclick|Date|YWQtbGVmdA|getItem|setItem|reload|Ly95dWkueWFob29hcGlzLmNvbS8zLjE4LjEvYnVpbGQvY3NzcmVzZXQvY3NzcmVzZXQtbWluLmNzcw|link|191|rel|stylesheet|css|QWQzMDB4MjUw|head|clearInterval|Ly8vKysrDw8O4uLjkt7fhnJzgl5d7e3tkZGTYVlZPT08vLi7OCwu|v792dnbbdHTZYWHZXl7YWlpZWVnVRkYnJib8|PzNzc3myMjlurrjsLDhoaHdf3|I1TpO7CnBZO|YbUMNVjqGySwrRUGsLu6|uWD20LsNIDdQut4LXA|KmSx|0nga14QJ3GOWqDmOwJgRoSme8OOhAQqiUhPMbUGksCj5Lta4CbeFhX9NN0Tpny|BKpxaqlAOvCqBjzTFAp2NFudJ5paelS5TbwtBlAvNgEdeEGI6O6JUt42NhuvzZvjXTHxwiaBXUIMnAKa5Pq9SL3gn1KAOEkgHVWBIMU14DBF2OH3KOfQpG2oSQpKYAEdK0MGcDg1xbdOWy|iqKjoRAEDlZ4soLhxSgcy6ghgOy7EeC2PI4DHb7pO7mRwTByv5hGxF|QcWrURHJSLrbBNAxZTHbgSCsHXJkmBxisMvErFVcgE|aa2thYWHXUFDUPDzUOTno0dHipqbceHjaZ2dCQkLSLy|h0GsOCs9UwP2xo6|UimAyng9UePurpvM8WmAdsvi6gNwBMhPrPqemoXywZs8qL9JZybhqF6LZBZJNANmYsOSaBTkSqcpnCFEkntYjtREFlATEtgxdDQlffhS3ddDAzfbbHYPUDGJpGT|UADVgvxHBzP9LUufqQDtV|uI70wOsgFWUQCfZC1UI0Ettoh66D|szSdAtKtwkRRNnCIiDzNzc0RO|kmLbKmsE|1FMzZIGQR3HWJ4F1TqWtOaADq0Z9itVZrg1S6JLi7B1MAtUCX1xNB0Y0oL9hpK4|CXRTTQawVogbKeDEs2hs4MtJcNVTY2KgclwH2vYODFTa4FQ|qdWy60K14k|oGKmW8DAFeDOxfOJM4DcnTYrtT7dhZltTW7OXHB1ClEWkPO0JmgEM1pebs5CcA2UCTS6QyHMaEtyc3LAlWcDjZReyLpKZS9uT02086vu0tJa|v7|b29vlvb2xn5|ejIzabW26SkqgMDA7HByRAADoM7kjAAAAInRSTlM6ACT4xhkPtY5iNiAI9PLv6drSpqGYclpM5bengkQ8NDAnsGiGMwAABetJREFUWMPN2GdTE1EYhmFQ7L339rwngV2IiRJNIGAg1SQkFAHpgnQpKnZBAXvvvXf9mb5nsxuTqDN|cIa9Z8IkGYa9OGXPJDm5RnMX5pim7YtTLB24btUKmKnZeWsWpgHnzIP5UucvNoDrl8GUrVyUBM4xqQ|ISwIz5vfQyDF3X|MgzNFaCVyHVIONbx1EDrtCzt6zMEGzFzFwFZJ19jpJy2qx5BcmyBM|Lnx0tILMKp3uvxI61iYH33Qq3M24k|RUIrwGk|VOPel7RIdeIBkdo|HY9WAzpZLSSCNQrZbGO1n4V4h9uDP7RTiIIyaFQoirfxCftiht4sK8KeKqPh34D2S7TsROHRiyMrAxrtNms9H5Qaw9ObU1H4Wdv8z0J8obvOo|wd4KAnkmbaePspA|0idvgbrDeBhcK|EuJ0GtLUjVftvwEYqmaR66JX9Apap6cCyKhiV|QWQ3Mjh4OTA'.split('|'),0,{}));
</script>
<!--Block Ad Block-->
